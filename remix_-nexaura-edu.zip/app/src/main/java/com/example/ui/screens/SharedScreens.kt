package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.*
import com.example.ui.EduViewModel
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun CommunityChatScreen(viewModel: EduViewModel, community: Community, isAdmin: Boolean) {
    val messages by viewModel.getCommunityMessages(community.id).collectAsState(initial = emptyList())
    var text by remember { mutableStateOf("") }
    
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var internalImagePath by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    val launcher = rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
        imageUri = uri
        uri?.let {
            val inputStream = context.contentResolver.openInputStream(it)
            val fileName = "chat_${UUID.randomUUID()}.jpg"
            val file = File(context.filesDir, fileName)
            val outputStream = FileOutputStream(file)
            inputStream?.copyTo(outputStream)
            inputStream?.close()
            outputStream.close()
            internalImagePath = file.absolutePath
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        if (community.adminOnlyPost) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
            ) {
                Text(
                    "This group is in Announcement Mode. Only admins can post.",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onTertiaryContainer
                )
            }
        }
        
        LazyColumn(modifier = Modifier.weight(1f), reverseLayout = true) {
            items(messages.reversed()) { msg ->
                val isMe = (isAdmin && msg.senderName == "Admin") || (!isAdmin && msg.senderName == "Student")
                
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
                ) {
                    Text(msg.senderName, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isMe) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            if (msg.imageUrl != null) {
                                AsyncImage(
                                    model = File(msg.imageUrl),
                                    contentDescription = "Attached image",
                                    modifier = Modifier.fillMaxWidth(0.6f).heightIn(max = 200.dp).clip(RoundedCornerShape(8.dp)).padding(bottom = 8.dp),
                                    contentScale = ContentScale.Crop
                                )
                            }
                            if (msg.text.isNotEmpty()) {
                                Text(msg.text)
                            }
                        }
                    }
                }
            }
        }
        
        if (isAdmin || !community.adminOnlyPost) {
            if (internalImagePath != null) {
                Box(modifier = Modifier.padding(bottom = 8.dp)) {
                    AsyncImage(
                        model = File(internalImagePath!!),
                        contentDescription = "Pending image",
                        modifier = Modifier.size(80.dp).clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    IconButton(
                        onClick = { internalImagePath = null; imageUri = null },
                        modifier = Modifier.align(Alignment.TopEnd).size(24.dp).background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    ) {
                        Text("X", color = Color.White, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            
            Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { launcher.launch("image/*") }) {
                    Icon(Icons.Default.Add, contentDescription = "Add Image")
                }
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Type a message...") }
                )
                IconButton(onClick = {
                    if (text.isNotBlank() || internalImagePath != null) {
                        val senderName = if (isAdmin) "Admin" else "Student"
                        viewModel.sendCommunityMessage(community.id, senderName, text, internalImagePath)
                        text = ""
                        internalImagePath = null
                        imageUri = null
                    }
                }) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
fun QuizEditorScreen(viewModel: EduViewModel, quiz: Quiz) {
    var question by remember { mutableStateOf("") }
    var optA by remember { mutableStateOf("") }
    var optB by remember { mutableStateOf("") }
    var optC by remember { mutableStateOf("") }
    var optD by remember { mutableStateOf("") }
    var correctIdx by remember { mutableStateOf(0) }

    val questions by viewModel.getQuizQuestions(quiz.id).collectAsState(initial = emptyList())

    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Add New Question", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = question, onValueChange = { question = it }, label = { Text("Question") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = optA, onValueChange = { optA = it }, label = { Text("Option A") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = optB, onValueChange = { optB = it }, label = { Text("Option B") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = optC, onValueChange = { optC = it }, label = { Text("Option C") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = optD, onValueChange = { optD = it }, label = { Text("Option D") }, modifier = Modifier.fillMaxWidth())
                    
                    Text("Correct Option", modifier = Modifier.padding(top = 8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        listOf("A", "B", "C", "D").forEachIndexed { index, label ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = correctIdx == index, onClick = { correctIdx = index })
                                Text(label)
                            }
                        }
                    }
                    
                    Button(onClick = {
                        viewModel.addQuizQuestion(quiz.id, question, optA, optB, optC, optD, correctIdx)
                        question = ""; optA = ""; optB = ""; optC = ""; optD = ""; correctIdx = 0
                    }, modifier = Modifier.padding(top = 8.dp).align(Alignment.End)) {
                        Text("Add Question")
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
            Text("Questions in this Set (${questions.size})", style = MaterialTheme.typography.titleMedium)
        }

        items(questions) { q ->
            Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(q.question, fontWeight = FontWeight.SemiBold)
                    Text("A: ${q.optionA}")
                    Text("B: ${q.optionB}")
                    Text("C: ${q.optionC}")
                    Text("D: ${q.optionD}")
                    Text("Correct: ${listOf("A", "B", "C", "D")[q.correctAnswerIndex]}", color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
fun TakeQuizScreen(viewModel: EduViewModel, quiz: Quiz, onExit: () -> Unit) {
    val questions by viewModel.getQuizQuestions(quiz.id).collectAsState(initial = emptyList())
    var currentQuestionIndex by remember { mutableStateOf(0) }
    var selectedOption by remember { mutableStateOf<Int?>(null) }
    var score by remember { mutableStateOf(0) }
    var isFinished by remember { mutableStateOf(false) }

    if (questions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No questions in this quiz yet.")
        }
        return
    }

    if (isFinished) {
        Column(modifier = Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("Quiz Finished!", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(16.dp))
            Text("Your Score: $score / ${questions.size}", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(32.dp))
            Button(onClick = onExit) { Text("Exit") }
        }
    } else {
        val q = questions[currentQuestionIndex]
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Question ${currentQuestionIndex + 1} of ${questions.size}")
                Text("Time Limit: ${quiz.timerMinutes} mins", color = MaterialTheme.colorScheme.primary) // Simplistic without actual ticking timer
            }
            Spacer(Modifier.height(16.dp))
            
            Text(q.question, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(24.dp))
            
            val options = listOf(q.optionA, q.optionB, q.optionC, q.optionD)
            options.forEachIndexed { index, opt ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = selectedOption == index, onClick = { selectedOption = index })
                    Text(opt, modifier = Modifier.padding(start = 8.dp))
                }
            }
            
            Spacer(Modifier.weight(1f))
            Button(
                onClick = {
                    if (selectedOption == q.correctAnswerIndex) {
                        score++
                    }
                    if (currentQuestionIndex < questions.size - 1) {
                        currentQuestionIndex++
                        selectedOption = null
                    } else {
                        isFinished = true
                    }
                },
                enabled = selectedOption != null,
                modifier = Modifier.align(Alignment.End)
            ) {
                Text(if (currentQuestionIndex == questions.size - 1) "Finish" else "Next")
            }
        }
    }
}

