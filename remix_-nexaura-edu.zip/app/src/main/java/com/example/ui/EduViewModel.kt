package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class EduViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: EduRepository
    
    init {
        val dao = EduDatabase.getDatabase(application).eduDao()
        repository = EduRepository(dao)
        
        // Let's prepopulate some initial permissions if not set
        viewModelScope.launch {
            repository.insertPermission(PermissionSetting("student_chat", true))
            repository.insertPermission(PermissionSetting("student_comments", true))
            repository.insertPermission(PermissionSetting("view_members", true))
            repository.insertPermission(PermissionSetting("add_members", false))
            repository.insertPermission(PermissionSetting("download_files", true))
            repository.insertPermission(PermissionSetting("upload_files", false))
            repository.insertPermission(PermissionSetting("polls", true))
            repository.insertPermission(PermissionSetting("reactions", true))
        }
    }

    val banners = repository.allBanners.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val communities = repository.allCommunities.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val quizzes = repository.allQuizzes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val notes = repository.allNotes.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val resources = repository.allResources.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val announcements = repository.allAnnouncements.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val permissions = repository.allPermissions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Actions
    fun addBanner(title: String, subtitle: String, imageUrl: String, buttonText: String, buttonLink: String) = viewModelScope.launch {
        repository.insertBanner(Banner(title = title, subtitle = subtitle, imageUrl = imageUrl, buttonText = buttonText, buttonLink = buttonLink))
    }
    
    fun deleteBanner(id: Int) = viewModelScope.launch {
        repository.deleteBanner(id)
    }

    fun addCommunity(name: String, description: String, adminOnlyPost: Boolean = false) = viewModelScope.launch {
        repository.insertCommunity(Community(name = name, description = description, adminOnlyPost = adminOnlyPost))
    }
    
    fun deleteCommunity(id: Int) = viewModelScope.launch { repository.deleteCommunity(id) }

    fun addQuiz(title: String, timerMinutes: Int, isPublished: Boolean) = viewModelScope.launch {
        repository.insertQuiz(Quiz(title = title, timerMinutes = timerMinutes, isPublished = isPublished))
    }
    
    fun deleteQuiz(id: Int) = viewModelScope.launch { repository.deleteQuiz(id) }

    fun getCommunityMessages(communityId: Int) = repository.getCommunityMessages(communityId)
    
    fun sendCommunityMessage(communityId: Int, senderName: String, text: String, imageUrl: String? = null) = viewModelScope.launch {
        repository.insertCommunityMessage(CommunityMessage(communityId = communityId, senderName = senderName, text = text, imageUrl = imageUrl))
    }
    
    fun getQuizQuestions(quizId: Int) = repository.getQuizQuestions(quizId)
    
    fun addQuizQuestion(quizId: Int, question: String, optionA: String, optionB: String, optionC: String, optionD: String, correctAnswerIndex: Int) = viewModelScope.launch {
        repository.insertQuizQuestion(QuizQuestion(quizId = quizId, question = question, optionA = optionA, optionB = optionB, optionC = optionC, optionD = optionD, correctAnswerIndex = correctAnswerIndex))
    }

    fun addNote(title: String, format: String, url: String) = viewModelScope.launch {
        repository.insertNote(Note(title = title, format = format, url = url))
    }

    fun addResource(title: String, type: String, url: String) = viewModelScope.launch {
        repository.insertResource(ResourceLink(title = title, type = type, url = url))
    }

    fun addAnnouncement(title: String, content: String) = viewModelScope.launch {
        repository.insertAnnouncement(Announcement(title = title, content = content))
    }

    fun togglePermission(id: String, isEnabled: Boolean) = viewModelScope.launch {
        repository.insertPermission(PermissionSetting(id, isEnabled))
    }

    // Auth State - simple in-memory for this prototype
    private val _isAdminLoggedIn = MutableStateFlow(false)
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn
    
    private val _isStudentLoggedIn = MutableStateFlow(false)
    val isStudentLoggedIn: StateFlow<Boolean> = _isStudentLoggedIn

    fun loginAdmin() {
        _isAdminLoggedIn.value = true
        _isStudentLoggedIn.value = false
    }

    fun loginStudent() {
        _isAdminLoggedIn.value = false
        _isStudentLoggedIn.value = true
    }

    fun logout() {
        _isAdminLoggedIn.value = false
        _isStudentLoggedIn.value = false
    }
}
