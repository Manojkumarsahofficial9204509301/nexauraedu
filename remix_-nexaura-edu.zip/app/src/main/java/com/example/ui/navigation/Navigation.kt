package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.EduViewModel
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.AdminDashboard
import com.example.ui.screens.StudentDashboard

@Composable
fun EduApp() {
    val navController = rememberNavController()
    val viewModel: EduViewModel = viewModel()
    
    val isAdminLoggedIn by viewModel.isAdminLoggedIn.collectAsState()
    val isStudentLoggedIn by viewModel.isStudentLoggedIn.collectAsState()

    val startDestination = when {
        isAdminLoggedIn -> "admin_dashboard"
        isStudentLoggedIn -> "student_dashboard"
        else -> "login"
    }

    NavHost(navController = navController, startDestination = startDestination) {
        composable("login") {
            LoginScreen(
                onLoginAdmin = {
                    viewModel.loginAdmin()
                },
                onLoginStudent = {
                    viewModel.loginStudent()
                }
            )
        }
        composable("admin_dashboard") {
            AdminDashboard(
                viewModel = viewModel,
                onLogout = { viewModel.logout() }
            )
        }
        composable("student_dashboard") {
            StudentDashboard(
                viewModel = viewModel,
                onLogout = { viewModel.logout() }
            )
        }
    }
}
