package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.EduViewModel
import com.example.data.*
import java.text.SimpleDateFormat
import java.util.*
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentDashboard(
    viewModel: EduViewModel,
    onLogout: () -> Unit
) {
    var selectedCommunity by remember { mutableStateOf<Community?>(null) }
    var selectedQuiz by remember { mutableStateOf<Quiz?>(null) }

    val banners by viewModel.banners.collectAsState()
    val communities by viewModel.communities.collectAsState()
    val quizzes by viewModel.quizzes.collectAsState()
    val notes by viewModel.notes.collectAsState()
    val resources by viewModel.resources.collectAsState()
    val announcements by viewModel.announcements.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        when {
                            selectedCommunity != null -> "Chat: ${selectedCommunity?.name}"
                            selectedQuiz != null -> "Quiz: ${selectedQuiz?.title}"
                            else -> "Nexaura Edu"
                        }
                    ) 
                },
                navigationIcon = {
                    if (selectedCommunity != null || selectedQuiz != null) {
                        IconButton(onClick = { 
                            selectedCommunity = null
                            selectedQuiz = null
                        }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    if (selectedCommunity == null && selectedQuiz == null) {
                        IconButton(onClick = { /* Handle Notifications */ }) {
                           Icon(Icons.Default.Notifications, contentDescription = "Notifications")
                        }
                        IconButton(onClick = onLogout) {
                            Icon(Icons.Default.ExitToApp, contentDescription = "Logout")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when {
                selectedCommunity != null -> {
                    CommunityChatScreen(viewModel, selectedCommunity!!, isAdmin = false)
                }
                selectedQuiz != null -> {
                    TakeQuizScreen(viewModel, selectedQuiz!!) { selectedQuiz = null }
                }
                else -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 32.dp)
                    ) {
                        
                        // 1. Banner Slider
                        if (banners.isNotEmpty()) {
                            item {
                                Text("Featured", modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), style = MaterialTheme.typography.titleLarge)
                                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                    items(banners) { banner ->
                                        BannerCard(banner)
                                    }
                                }
                            }
                        }

                        // 6. Announcements
                        if (announcements.isNotEmpty()) {
                            item {
                                Text("Latest Announcements", modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 8.dp), style = MaterialTheme.typography.titleMedium)
                            }
                            items(announcements.take(3)) { ann ->
                                AnnouncementItem(ann)
                            }
                        }

                        // 2. Communities
                        if (communities.isNotEmpty()) {
                            item {
                                Text("Communities", modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 8.dp), style = MaterialTheme.typography.titleMedium)
                                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                    items(communities) { comm ->
                                        CommunityCard(comm) { selectedCommunity = it }
                                    }
                                }
                            }
                        }

                        // 3. Quiz Center
                        if (quizzes.isNotEmpty()) {
                            item {
                                Text("Quizzes", modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 8.dp), style = MaterialTheme.typography.titleMedium)
                            }
                            items(quizzes.filter { it.isPublished }) { quiz ->
                                QuizItem(quiz) { selectedQuiz = it }
                            }
                        }

                        // 4. Notes & 5. Resources Center
                        if (notes.isNotEmpty() || resources.isNotEmpty()) {
                            item {
                                Text("Study Materials", modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 8.dp), style = MaterialTheme.typography.titleMedium)
                            }
                            items(notes) { note ->
                                ListCardItem(note.title, note.format)
                            }
                            items(resources) { res ->
                                ListCardItem(res.title, res.type)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BannerCard(banner: Banner) {
    Card(
        modifier = Modifier
            .width(300.dp)
            .height(140.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            if (banner.imageUrl.isNotEmpty()) {
                val model = if (banner.imageUrl.startsWith("/")) File(banner.imageUrl) else banner.imageUrl
                AsyncImage(
                    model = model,
                    contentDescription = banner.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    alpha = 0.5f // Dim the image slightly so text is readable
                )
            }
            Column(modifier = Modifier.padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                Text(banner.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondaryContainer)
                Button(onClick = { /* Handle Link */ }) {
                    Text(banner.buttonText)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommunityCard(community: Community, onClick: (Community) -> Unit) {
    Card(
        onClick = { onClick(community) },
        modifier = Modifier.width(160.dp).height(120.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(community.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(community.description, style = MaterialTheme.typography.bodySmall, maxLines = 2)
        }
    }
}

@Composable
fun AnnouncementItem(ann: Announcement) {
    val formatter = remember { SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()) }
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(ann.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(ann.content, style = MaterialTheme.typography.bodyMedium)
        Text(formatter.format(Date(ann.timestamp)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
        HorizontalDivider(modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
fun QuizItem(quiz: Quiz, onClick: (Quiz) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
    ) {
        Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text(quiz.title, fontWeight = FontWeight.SemiBold)
                Text("Time Limit: ${quiz.timerMinutes} mins", style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = { onClick(quiz) }) { Text("Start") }
        }
    }
}

@Composable
fun ListCardItem(title: String, subtitle: String) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Medium)
                Text(subtitle, style = MaterialTheme.typography.labelMedium)
            }
            FilledTonalButton(onClick = { /* Action */ }) { Text("View") }
        }
    }
}
