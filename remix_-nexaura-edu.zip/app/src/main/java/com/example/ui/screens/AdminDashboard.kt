package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.*
import com.example.ui.EduViewModel
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import java.io.FileOutputStream
import java.io.File
import java.util.UUID
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboard(
    viewModel: EduViewModel,
    onLogout: () -> Unit
) {
    var selectedCommunity by remember { mutableStateOf<Community?>(null) }
    var selectedQuiz by remember { mutableStateOf<Quiz?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        when {
                            selectedCommunity != null -> "Chat: ${selectedCommunity?.name}"
                            selectedQuiz != null -> "Quiz: ${selectedQuiz?.title}"
                            else -> "Admin Dashboard"
                        }
                    ) 
                },
                navigationIcon = {
                    if (selectedCommunity != null || selectedQuiz != null) {
                        IconButton(onClick = { 
                            selectedCommunity = null
                            selectedQuiz = null
                        }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    if (selectedCommunity == null && selectedQuiz == null) {
                        IconButton(onClick = onLogout) {
                            Icon(Icons.Default.ExitToApp, contentDescription = "Logout")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when {
                selectedCommunity != null -> {
                    CommunityChatScreen(viewModel, selectedCommunity!!, isAdmin = true)
                }
                selectedQuiz != null -> {
                    QuizEditorScreen(viewModel, selectedQuiz!!)
                }
                else -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item { BannerManagerSection(viewModel) }
                        item { CommunityManagerSection(viewModel) { selectedCommunity = it } }
                        item { QuizCenterSection(viewModel) { selectedQuiz = it } }
                        item { NotesCenterSection(viewModel) }
                        item { ResourcesCenterSection(viewModel) }
                        item { AnnouncementCenterSection(viewModel) }
                        item { PermissionManagerSection(viewModel) }
                        item { Spacer(Modifier.height(32.dp)) }
                    }
                }
            }
        }
    }
}

@Composable
fun BannerManagerSection(viewModel: EduViewModel) {
    ExpandableSection(title = "Banner Manager") {
        var title by remember { mutableStateOf("") }
        var link by remember { mutableStateOf("") }
        var imageUri by remember { mutableStateOf<Uri?>(null) }
        var internalImagePath by remember { mutableStateOf<String?>(null) }
        val context = LocalContext.current

        val launcher = rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
            imageUri = uri
            uri?.let {
                // Copy the selected file to internal storage so we have persisted access to it
                val inputStream = context.contentResolver.openInputStream(it)
                val fileName = "banner_${UUID.randomUUID()}.jpg"
                val file = File(context.filesDir, fileName)
                val outputStream = FileOutputStream(file)
                inputStream?.copyTo(outputStream)
                inputStream?.close()
                outputStream.close()
                internalImagePath = file.absolutePath
            }
        }
        
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Banner Title") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = link, onValueChange = { link = it }, label = { Text("Action Link") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Button(onClick = { launcher.launch("image/*") }) {
                Text(if (internalImagePath != null) "Change Banner Image" else "Upload Banner Image")
            }
            Spacer(Modifier.width(8.dp))
            if (internalImagePath != null) {
                AsyncImage(
                    model = File(internalImagePath!!),
                    contentDescription = "Selected Banner Image",
                    modifier = Modifier.size(64.dp).clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop
                )
            } else {
                Text("No image selected", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
            }
        }

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { 
                viewModel.addBanner(
                    title = title.ifEmpty { "New Banner" }, 
                    subtitle = "Subtitle", 
                    imageUrl = internalImagePath ?: "https://via.placeholder.com/600x300", 
                    buttonText = "Click Here", 
                    buttonLink = link
                )
                title = ""
                link = ""
                imageUri = null
                internalImagePath = null
            },
            enabled = internalImagePath != null || title.isNotEmpty()
        ) {
            Text("Create Banner")
        }
        
        Spacer(Modifier.height(16.dp))
        val banners by viewModel.banners.collectAsState()
        banners.forEach { banner ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("- ${banner.title}", fontWeight = androidx.compose.ui.text.font.FontWeight.Medium)
                    if (banner.imageUrl.startsWith("/")) {
                        Text("Has local image", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
                IconButton(onClick = { viewModel.deleteBanner(banner.id) }) {
                   Icon(Icons.Default.Delete, "Delete", tint = MaterialTheme.colorScheme.error)
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun CommunityManagerSection(viewModel: EduViewModel, onCommunitySelected: (Community) -> Unit) {
    ExpandableSection(title = "Community Manager") {
        var name by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var adminOnlyPost by remember { mutableStateOf(false) }
        
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Group Name") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text("Admin Only Posts (Announcement Mode)", modifier = Modifier.weight(1f))
            Switch(checked = adminOnlyPost, onCheckedChange = { adminOnlyPost = it })
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = { viewModel.addCommunity(name, desc, adminOnlyPost); name = ""; desc = ""; adminOnlyPost = false }) { Text("Create Community") }

        Spacer(Modifier.height(16.dp))
        val communities by viewModel.communities.collectAsState()
        communities.forEach { comm ->
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("- ${comm.name}", fontWeight = androidx.compose.ui.text.font.FontWeight.Medium)
                    if (comm.adminOnlyPost) {
                        Text("Announcements Only", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
                Row {
                    TextButton(onClick = { onCommunitySelected(comm) }) { Text("Chat") }
                    IconButton(onClick = { viewModel.deleteCommunity(comm.id) }) {
                        Icon(Icons.Default.Delete, "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
fun QuizCenterSection(viewModel: EduViewModel, onQuizSelected: (Quiz) -> Unit) {
    ExpandableSection(title = "Quiz Center") {
        var title by remember { mutableStateOf("") }
        var time by remember { mutableStateOf("15") }
        
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Quiz Title (Set Name)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("Time Limit (Minutes)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(onClick = { viewModel.addQuiz(title, time.toIntOrNull() ?: 15, true); title = "" }) { Text("Create Quiz Set") }

        Spacer(Modifier.height(16.dp))
        val quizzes by viewModel.quizzes.collectAsState()
        quizzes.forEach { quiz ->
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("- ${quiz.title}")
                    Text("${quiz.timerMinutes} mins", style = MaterialTheme.typography.bodySmall)
                }
                Row {
                    TextButton(onClick = { onQuizSelected(quiz) }) { Text("Edit") }
                    IconButton(onClick = { viewModel.deleteQuiz(quiz.id) }) {
                        Icon(Icons.Default.Delete, "Delete", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

@Composable
fun NotesCenterSection(viewModel: EduViewModel) {
    ExpandableSection(title = "Notes Center") {
        var title by remember { mutableStateOf("") }
        
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Note Title (PDF/DOCX simulated)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(onClick = { viewModel.addNote(title, "PDF", "http://example.com"); title = "" }) { Text("Upload Note") }
    }
}

@Composable
fun ResourcesCenterSection(viewModel: EduViewModel) {
    ExpandableSection(title = "Resources Center") {
        var title by remember { mutableStateOf("") }
        var url by remember { mutableStateOf("") }
        
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Resource Title") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("URL (Youtube, Telegram, etc)") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(onClick = { viewModel.addResource(title, "Link", url); title = ""; url = "" }) { Text("Add Resource") }
    }
}

@Composable
fun AnnouncementCenterSection(viewModel: EduViewModel) {
    ExpandableSection(title = "Announcement Center") {
        var title by remember { mutableStateOf("") }
        var content by remember { mutableStateOf("") }
        
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("Content") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(onClick = { viewModel.addAnnouncement(title, content); title = ""; content = "" }) { Text("Post Announcement") }
    }
}

@Composable
fun PermissionManagerSection(viewModel: EduViewModel) {
    ExpandableSection(title = "Permission Manager") {
        val permissions by viewModel.permissions.collectAsState()
        
        permissions.forEach { perm ->
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text(perm.id.replace("_", " ").uppercase())
                Switch(checked = perm.isEnabled, onCheckedChange = { viewModel.togglePermission(perm.id, it) })
            }
        }
    }
}

@Composable
fun ExpandableSection(title: String, content: @Composable () -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = { expanded = !expanded }) {
                    Icon(
                        if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = "Toggle"
                    )
                }
            }
            if (expanded) {
                Spacer(Modifier.height(16.dp))
                content()
            }
        }
    }
}
