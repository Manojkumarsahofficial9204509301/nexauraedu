package com.example.data

import kotlinx.coroutines.flow.Flow

class EduRepository(private val dao: EduDao) {
    val allBanners: Flow<List<Banner>> = dao.getAllBanners()
    val allCommunities: Flow<List<Community>> = dao.getAllCommunities()
    val allQuizzes: Flow<List<Quiz>> = dao.getAllQuizzes()
    val allNotes: Flow<List<Note>> = dao.getAllNotes()
    val allResources: Flow<List<ResourceLink>> = dao.getAllResources()
    val allAnnouncements: Flow<List<Announcement>> = dao.getAllAnnouncements()
    val allPermissions: Flow<List<PermissionSetting>> = dao.getAllPermissions()

    suspend fun insertBanner(banner: Banner) = dao.insertBanner(banner)
    suspend fun deleteBanner(id: Int) = dao.deleteBanner(id)
    
    suspend fun insertCommunity(community: Community): Long = dao.insertCommunity(community)
    suspend fun deleteCommunity(id: Int) = dao.deleteCommunity(id)
    
    fun getCommunityMessages(communityId: Int) = dao.getCommunityMessages(communityId)
    suspend fun insertCommunityMessage(message: CommunityMessage) = dao.insertCommunityMessage(message)

    suspend fun insertQuiz(quiz: Quiz): Long = dao.insertQuiz(quiz)
    suspend fun deleteQuiz(id: Int) = dao.deleteQuiz(id)

    fun getQuizQuestions(quizId: Int) = dao.getQuizQuestions(quizId)
    suspend fun insertQuizQuestion(question: QuizQuestion) = dao.insertQuizQuestion(question)
    suspend fun insertNote(note: Note) = dao.insertNote(note)
    suspend fun insertResource(resource: ResourceLink) = dao.insertResource(resource)
    suspend fun insertAnnouncement(announcement: Announcement) = dao.insertAnnouncement(announcement)
    suspend fun insertPermission(permission: PermissionSetting) = dao.insertPermission(permission)
}
