package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "banners")
data class Banner(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val subtitle: String,
    val imageUrl: String,
    val buttonText: String,
    val buttonLink: String
)

@Entity(tableName = "communities")
data class Community(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String,
    val adminOnlyPost: Boolean = false
)

@Entity(tableName = "community_messages")
data class CommunityMessage(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val communityId: Int,
    val senderName: String, // "Admin" or Student Name
    val text: String,
    val imageUrl: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "quizzes")
data class Quiz(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val timerMinutes: Int,
    val isPublished: Boolean
)

@Entity(tableName = "quiz_questions")
data class QuizQuestion(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val quizId: Int,
    val question: String,
    val optionA: String,
    val optionB: String,
    val optionC: String,
    val optionD: String,
    val correctAnswerIndex: Int
)

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val format: String, // PDF, DOCX, etc.
    val url: String
)

@Entity(tableName = "resources")
data class ResourceLink(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val type: String, // YouTube, Telegram, Drive etc.
    val url: String
)

@Entity(tableName = "announcements")
data class Announcement(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "permissions")
data class PermissionSetting(
    @PrimaryKey val id: String,
    val isEnabled: Boolean
)
