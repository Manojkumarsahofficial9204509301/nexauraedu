package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface EduDao {
    @Query("SELECT * FROM banners")
    fun getAllBanners(): Flow<List<Banner>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBanner(banner: Banner)
    @Query("DELETE FROM banners WHERE id = :id")
    suspend fun deleteBanner(id: Int)

    @Query("SELECT * FROM communities")
    fun getAllCommunities(): Flow<List<Community>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommunity(community: Community): Long
    @Query("DELETE FROM communities WHERE id = :id")
    suspend fun deleteCommunity(id: Int)

    @Query("SELECT * FROM community_messages WHERE communityId = :communityId ORDER BY timestamp ASC")
    fun getCommunityMessages(communityId: Int): Flow<List<CommunityMessage>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommunityMessage(message: CommunityMessage)

    @Query("SELECT * FROM quizzes")
    fun getAllQuizzes(): Flow<List<Quiz>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuiz(quiz: Quiz): Long
    @Query("DELETE FROM quizzes WHERE id = :id")
    suspend fun deleteQuiz(id: Int)

    @Query("SELECT * FROM quiz_questions WHERE quizId = :quizId")
    fun getQuizQuestions(quizId: Int): Flow<List<QuizQuestion>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuizQuestion(question: QuizQuestion)

    @Query("SELECT * FROM notes")
    fun getAllNotes(): Flow<List<Note>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: Note)

    @Query("SELECT * FROM resources")
    fun getAllResources(): Flow<List<ResourceLink>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResource(resource: ResourceLink)

    @Query("SELECT * FROM announcements ORDER BY timestamp DESC")
    fun getAllAnnouncements(): Flow<List<Announcement>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncement(announcement: Announcement)
    
    @Query("SELECT * FROM permissions")
    fun getAllPermissions(): Flow<List<PermissionSetting>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPermission(permission: PermissionSetting)
}
